DECIDEX PRO — QUICK START

1. Download the ZIP and choose Extract All.
2. Open the extracted DecideX_Pro folder.
3. Double-click index.html to open it in Chrome or Edge.
4. Create a demo account from the sign-in screen. Use a demo email/password only.

What is included:
- Professional sign-in and create-account screens
- Responsive dashboard with clear navigation
- 12 decision categories and tailored mini action plans
- Saved plans, reminders, and project story section
- Browser-local demo storage

Important competition-demo limitations:
- This is a front-end prototype. Accounts and data are stored in browser localStorage, not a secure server.
- Passwords are stored locally in plain text for demo purposes. Never use a real or reused password.
- Data is tied to the browser/device and may disappear if site data is cleared.
- Notifications are best-effort and require the page to stay open.
- Recommendations are rule-based, not live AI.
